package pawel.zalejko.sample.containerinfo;

import java.util.Optional;

public class ContainerInfoProvider {

    public Optional<ContainerInfo> getInfo() {
        return Optional.empty();
    }
}
