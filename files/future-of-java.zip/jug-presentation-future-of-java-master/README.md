# My presentation about the state of Java

- What's new in Java 11
- Java LTS
- OpenJDK and different builds
- A few words about JVM implementations (Hotspot, OpenJ9, GraalVM) 
- A simple hello world application launched with different builds and JVMs
- How to build OpenJDK: https://github.com/p-zalejko/openjdk
