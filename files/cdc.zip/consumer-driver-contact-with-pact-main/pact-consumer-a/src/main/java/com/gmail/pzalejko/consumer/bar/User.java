package com.gmail.pzalejko.consumer.bar;

public record User(String id, String name, String email) {
    
}
