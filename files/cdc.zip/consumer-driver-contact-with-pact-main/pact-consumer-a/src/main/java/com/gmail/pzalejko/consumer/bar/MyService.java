package com.gmail.pzalejko.consumer.bar;

import org.springframework.stereotype.Service;

@Service
public class MyService {
    
    public void doSomething(User user){

    }
}
