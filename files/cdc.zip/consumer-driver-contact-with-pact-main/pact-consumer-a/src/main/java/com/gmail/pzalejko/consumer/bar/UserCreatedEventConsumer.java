package com.gmail.pzalejko.consumer.bar;

import org.springframework.stereotype.Service;

@Service
public class UserCreatedEventConsumer {

    public void handle(UserCreatedEvent event) {
        //
    }

}
