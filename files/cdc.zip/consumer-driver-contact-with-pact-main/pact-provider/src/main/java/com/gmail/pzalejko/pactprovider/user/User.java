package com.gmail.pzalejko.pactprovider.user;

record User(long id, String name, String email) {

}
