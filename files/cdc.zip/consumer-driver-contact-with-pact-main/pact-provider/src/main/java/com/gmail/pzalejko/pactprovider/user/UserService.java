package com.gmail.pzalejko.pactprovider.user;

import java.util.Optional;

import org.springframework.stereotype.Service;

@Service
class UserService {

    Optional<User> findUserById(long id) {
        throw new UnsupportedOperationException("Not implemented yet");
    }
}
