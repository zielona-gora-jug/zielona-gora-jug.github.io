# Consumer-Driver Contact + Pact (http://pact.io/)

A simple application that shows how pact can be used:
- two consumers
- one provider
- contracts for REST API
- contracts for events

# Presentation

https://p-zalejko.github.io/consumer-driver-contact-with-pact
