package com.gmail.pzalejko.pact.consumer.foo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PactConsumerFooApplicarion {
	
	public static void main(String[] args) {
		SpringApplication.run(PactConsumerFooApplicarion.class, args);
	}

}
