package io.github.mstachniuk.graphqljavaexample.company;

public class Company {
    private String id;
    private String name;
    private String website;

    public Company(String id, String name, String website) {
        this.id = id;
        this.name = name;
        this.website = website;
    }
}
