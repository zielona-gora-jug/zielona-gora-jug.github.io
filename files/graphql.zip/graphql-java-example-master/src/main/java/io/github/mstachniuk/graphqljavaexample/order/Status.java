package io.github.mstachniuk.graphqljavaexample.order;

public enum Status {
	NEW, CANCELED, DONE
}
